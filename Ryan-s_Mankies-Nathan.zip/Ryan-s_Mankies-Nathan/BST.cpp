#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include "BST.h"

using namespace std;


// Default Constructor
BST::BST()
{
	roots;
}


// Creates a new node
BST::node* BST::createNewLeaf(string nodeData)
{
	node* newNode = new node;
	newNode->nodeData = nodeData;
	newNode->Left = NULL;
	newNode->Right = NULL;

	return newNode;
}


// Wrapper functon for function below
BST::node* BST::getNodeData(string nodeData) const
{
	return getNodeDataPrivate(nodeData, roots);
}


// Retrieves node data
BST::node* BST::getNodeDataPrivate(string nodeData, node* ptr) const
{

	if (ptr != NULL)
	{
		if (ptr->nodeData == nodeData)
		{
			return ptr;
		}
		else
		{
			if (nodeData < ptr->nodeData)
			{
				return getNodeDataPrivate(nodeData, ptr->Left);
			}
			else
			{
				return getNodeDataPrivate(nodeData, ptr->Right);
			}
		}
	}
	else
	{
		return NULL;
	}

}


// Wrapper functon for function below
void BST::addLeaf(string nodeData)
{
	addLeafPrivate(nodeData, roots);
}


// Adds a leaf to current tree
void BST::addLeafPrivate(string nodeData, node* ptr)
{
	if (roots == NULL)
	{
		roots = createNewLeaf(nodeData);
	}
	else if (nodeData < ptr->nodeData)
	{
		if (ptr->Left != NULL)
		{
			addLeafPrivate(nodeData, ptr->Left);
		}
		else
		{
			ptr->Left = createNewLeaf(nodeData);
		}
	}
	else if (nodeData > ptr->nodeData)
	{
		if (ptr->Right != NULL)
		{
			addLeafPrivate(nodeData, ptr->Right);
		}
		else
		{
			ptr->Right = createNewLeaf(nodeData);
		}

	}
	else
	{
		cout << "The data '" << nodeData << "' is already in the tree." << endl;
	}

}


// Wrapper functon for function below
void BST::printInOrder() const
{
	PrintInOrderPrivate(roots);
}


// Prints the node data values in sorted order
void BST::PrintInOrderPrivate(node* ptr) const
{
	if (roots != NULL)
	{
		if (ptr->Left != NULL)
		{
			PrintInOrderPrivate(ptr->Left);
		}
		cout << ptr->nodeData << " ";
		if (ptr->Right != NULL)
		{
			PrintInOrderPrivate(ptr->Right);
		}
	}
	else
	{
		cout << "Tree is empty. " << endl;
	}
}


// Prints the children of the current node
void BST::printChildren(string nodeData) const
{
	node* ptr = getNodeData(nodeData);

	if (ptr != NULL)
	{
		cout << endl << "Parent Node = " << ptr->nodeData << endl;

		if (ptr->Left == NULL)
		{
			cout << "Left Child = NULL" << endl;
		}
		else
		{
			cout << "Left Child = " << ptr->Left->nodeData << endl;
		}
		if (ptr->Right == NULL)
		{
			cout << "Right Child = NULL" << endl;
		}
		else
		{
			cout << "Right Child = " << ptr->Right->nodeData << endl;
		}

	}
	else
	{
		cout << "Data '" << nodeData << "' is not in the tree." << endl;
	}
}


// Returns the root's data
string BST::getRootData() const
{
	return roots->nodeData;
}


// Checks if the current node is a leaf or not
bool BST::isLeaf() const
{
	if (roots != NULL)
	{
		if (left != NULL || right != NULL)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

}